/* Get home page */
const foodList = function(req, res){
    res.render('foodList', {title: 'Food List', foods:foodArray});
};

const myFavourteFood = function(req, res){
    res.render('myFavourite-food', {title: 'My Favourte Food', food:myFavFood});
};

const foodArray=[
    {name:"Oatmeal", type:"Breakfast"},
    {name:"Steak", type:"Lunch"},
    {name:"Salad", type:"Dinner"}
]

const myFavFood="Steak";


module.exports = {
    foodList,
    myFavourteFood
};  